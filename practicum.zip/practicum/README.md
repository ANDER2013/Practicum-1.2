# Pipeline Macroentorno Ecuador — UTPL
**Prácticum DGTITD · 4to ciclo · Python + SQLite**

---

## Estructura del proyecto

```
practicum/
│
├── bronze/              ← Archivos crudos descargados del BCE, INEC, etc.
│   ├── bce_pib_real.xlsx
│   ├── bce_pib_pc.xlsx
│   ├── bce_vab_prov.xlsx
│   ├── bce_petroleo_iee.xlsx
│   └── bce_iee.xlsx     (si viene separado)
│
├── silver/              ← Base de datos SQLite (se crea automáticamente)
│   └── macroentorno.db
│
├── gold/                ← Vistas Gold (semana 4)
│   └── gold_views.sql
│
├── transform/           ← Scripts ETL por fuente
│   ├── __init__.py
│   ├── bce.py           ← Semana 2 ✅
│   ├── inec.py          ← Semana 3
│   ├── supercias.py     ← Semana 3
│   └── mineduc.py       ← Semana 3
│
├── pipeline.py          ← Orquestador principal (semana 5)
├── requirements.txt     ← Dependencias Python
└── README.md
```

---

## Instalación (solo la primera vez)

```bash
# 1. Abre una terminal en la carpeta practicum/
# 2. Instala las dependencias:
pip install -r requirements.txt
```

---

## Semana 2 — Ejecutar pipeline BCE

```bash
# Desde la carpeta practicum/
python -m transform.bce
```

Verás en la consola cuántos registros se insertaron en cada tabla.

---

## Verificar la base de datos

```bash
python -c "
import sqlite3
conn = sqlite3.connect('silver/macroentorno.db')
tablas = ['dim_tiempo','dim_geografia','fact_macro_anual','fact_ind_diarios','fact_vab','fact_iee']
for t in tablas:
    n = conn.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
    print(f'{t:<30} {n:>8} registros')
conn.close()
"
```
