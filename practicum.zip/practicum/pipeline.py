"""
pipeline.py
===========
Orquestador principal del pipeline Macroentorno Ecuador.
Ejecuta todos los módulos ETL en orden.

Uso:
  python pipeline.py             → corre todo
  python pipeline.py --solo bce  → solo fuentes BCE
"""

import argparse
import logging
from transform import bce
# Semana 3: from transform import inec, supercias, mineduc

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


def main(solo=None):
    log.info("=" * 50)
    log.info("PIPELINE MACROENTORNO ECUADOR — UTPL")
    log.info("=" * 50)

    if solo is None or solo == "bce":
        log.info("--- Bloque 1: BCE ---")
        bce.run_bce_pipeline()

    # Semana 3 — descomentar cuando estén listos:
    # if solo is None or solo == "inec":
    #     log.info("--- Bloque 2: INEC ---")
    #     inec.run_inec_pipeline()
    #
    # if solo is None or solo == "supercias":
    #     log.info("--- Bloque 3: Supercias ---")
    #     supercias.run_supercias_pipeline()
    #
    # if solo is None or solo == "mineduc":
    #     log.info("--- Bloque 3: MINEDUC ---")
    #     mineduc.run_mineduc_pipeline()

    log.info("✅ Pipeline completo.")
    bce.verificar_carga()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--solo", help="Ejecutar solo un bloque: bce | inec | supercias | mineduc")
    args = parser.parse_args()
    main(solo=args.solo)
