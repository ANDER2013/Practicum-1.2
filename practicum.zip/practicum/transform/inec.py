"""
transform/inec.py
=================
ETL Capa Bronze → Silver  |  Fuentes: INEC
Semana 3 · Prácticum DGTITD-UTPL

Fuentes que procesará:
  1. ENEMDU (indicadores laborales) → fact_empleo   [requiere melt()]
  2. Censo 2022 (rama de actividad) → fact_censo
"""

# TODO Semana 3


def run_inec_pipeline():
    raise NotImplementedError("Implementar en Semana 3")
