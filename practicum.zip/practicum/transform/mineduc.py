"""
transform/mineduc.py
====================
ETL Capa Bronze → Silver  |  Fuentes: MINEDUC AMIE
Semana 3 · Prácticum DGTITD-UTPL

Fuentes que procesará:
  1. AMIE 2023-2024 → fact_bachilleres
     CSV con separador ; y encoding latin-1
     Filtrar: Nivel_Educacion = 'Bachillerato', último grado
"""

# TODO Semana 3


def run_mineduc_pipeline():
    raise NotImplementedError("Implementar en Semana 3")
