"""
transform/bce.py
================
ETL Capa Bronze → Silver  |  Fuentes: Banco Central del Ecuador
Semana 2 · Prácticum DGTITD-UTPL · 4to ciclo (SQLite)

Fuentes que procesa:
  1. PIB real anual         → fact_macro_anual
  2. PIB per cápita nominal → fact_macro_anual  (columna adicional)
  3. VAB por provincia      → fact_vab + dim_geografia
  4. Petróleo / Riesgo país → fact_ind_diarios
  5. IEE Expectativas       → fact_iee

Uso:
  python -m transform.bce
"""

import sqlite3
import logging
import pandas as pd
from pathlib import Path

# ─────────────────────────────────────────────────────────────
# RUTAS
# ─────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).resolve().parent.parent   # carpeta practicum/
BRONZE_DIR = BASE_DIR / "bronze"
DB_PATH    = BASE_DIR / "silver" / "macroentorno.db"

# ─────────────────────────────────────────────────────────────
# LOGGER
# ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────
# CONEXIÓN
# ─────────────────────────────────────────────────────────────
def get_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


# ─────────────────────────────────────────────────────────────
# DDL — CREAR TABLAS SILVER
# ─────────────────────────────────────────────────────────────
DDL = """
CREATE TABLE IF NOT EXISTS dim_tiempo (
    id_tiempo  INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha      TEXT    NOT NULL UNIQUE,
    anio       INTEGER NOT NULL,
    mes        INTEGER,
    trimestre  INTEGER
);

CREATE TABLE IF NOT EXISTS dim_geografia (
    id_geo        INTEGER PRIMARY KEY AUTOINCREMENT,
    provincia     TEXT    NOT NULL,
    cod_provincia INTEGER,
    canton        TEXT,
    cod_canton    INTEGER,
    UNIQUE (cod_provincia, cod_canton)
);

CREATE TABLE IF NOT EXISTS fact_macro_anual (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    id_tiempo             INTEGER REFERENCES dim_tiempo(id_tiempo),
    pib_real_musd         REAL,
    pib_percapita_usd     REAL,
    pib_percapita_nominal REAL,
    variacion_pib_pct     REAL
);

CREATE TABLE IF NOT EXISTS fact_ind_diarios (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    id_tiempo           INTEGER REFERENCES dim_tiempo(id_tiempo),
    fecha               TEXT    NOT NULL,
    precio_petroleo_wti REAL,
    riesgo_pais_pb      INTEGER
);

CREATE TABLE IF NOT EXISTS fact_vab (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    id_geo        INTEGER REFERENCES dim_geografia(id_geo),
    id_tiempo     INTEGER REFERENCES dim_tiempo(id_tiempo),
    anio          INTEGER,
    ciiu          TEXT,
    vab_miles_usd REAL
);

CREATE TABLE IF NOT EXISTS fact_iee (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    id_tiempo    INTEGER REFERENCES dim_tiempo(id_tiempo),
    fecha        TEXT    NOT NULL,
    iee_global   REAL,
    comercio     REAL,
    construccion REAL,
    manufactura  REAL
);
"""

def create_tables(conn):
    conn.executescript(DDL)
    conn.commit()
    log.info("Tablas Silver verificadas correctamente.")


# ─────────────────────────────────────────────────────────────
# HELPERS: insertar en dimensiones
# ─────────────────────────────────────────────────────────────
def upsert_dim_tiempo(conn, fecha_str: str) -> int:
    """Inserta la fecha si no existe y devuelve su id_tiempo."""
    f = pd.to_datetime(fecha_str)
    conn.execute(
        "INSERT OR IGNORE INTO dim_tiempo (fecha, anio, mes, trimestre) VALUES (?,?,?,?)",
        (fecha_str, int(f.year), int(f.month), int((f.month - 1) // 3 + 1))
    )
    return conn.execute(
        "SELECT id_tiempo FROM dim_tiempo WHERE fecha = ?", (fecha_str,)
    ).fetchone()[0]


def upsert_dim_geografia(conn, provincia, cod_prov, canton, cod_canton) -> int:
    """Inserta la combinación provincia/cantón si no existe y devuelve id_geo."""
    conn.execute(
        "INSERT OR IGNORE INTO dim_geografia (provincia, cod_provincia, canton, cod_canton) VALUES (?,?,?,?)",
        (str(provincia).strip().title(), int(cod_prov),
         str(canton).strip().title() if canton else None, int(cod_canton))
    )
    return conn.execute(
        "SELECT id_geo FROM dim_geografia WHERE cod_provincia=? AND cod_canton=?",
        (int(cod_prov), int(cod_canton))
    ).fetchone()[0]


# ─────────────────────────────────────────────────────────────
# FUNCIÓN 1 — PIB REAL ANUAL
# ─────────────────────────────────────────────────────────────
def transform_pib_real(conn, filepath: str):
    """
    Limpia y carga PIB real anual.
    Decisiones:
    - Variación del primer año (1965) = NULL → correcto, NO se elimina.
    - Columna Población se ignora (fuera del modelo).
    - Mapeo flexible de nombres de columna por palabras clave.
    """
    log.info("→ [1/5] PIB real: leyendo %s", filepath)
    df = pd.read_excel(filepath, engine="openpyxl")
    df.columns = [str(c).strip() for c in df.columns]

    rename = {}
    for col in df.columns:
        cl = col.lower()
        if "año" in cl or "anio" in cl or cl == "años":
            rename[col] = "anio"
        elif "pib" in cl and "percapita" not in cl and "nominal" not in cl:
            rename[col] = "pib_real_musd"
        elif "percapita" in cl or "per capita" in cl:
            rename[col] = "pib_percapita_usd"
        elif "variacion" in cl or "variación" in cl:
            rename[col] = "variacion_pib_pct"
    df.rename(columns=rename, inplace=True)

    df = df[df["anio"].notna()].copy()
    df["anio"] = df["anio"].astype(int)
    for col in ["pib_real_musd", "pib_percapita_usd", "variacion_pib_pct"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    log.info("   %d filas limpias (años %d–%d)", len(df), df["anio"].min(), df["anio"].max())

    for _, row in df.iterrows():
        id_t = upsert_dim_tiempo(conn, f"{int(row['anio'])}-01-01")
        conn.execute(
            "INSERT INTO fact_macro_anual (id_tiempo, pib_real_musd, pib_percapita_usd, variacion_pib_pct) VALUES (?,?,?,?)",
            (id_t, row.get("pib_real_musd"), row.get("pib_percapita_usd"), row.get("variacion_pib_pct"))
        )
    conn.commit()
    log.info("    %d registros en fact_macro_anual.", len(df))


# ─────────────────────────────────────────────────────────────
# FUNCIÓN 2 — PIB PER CÁPITA NOMINAL
# ─────────────────────────────────────────────────────────────
def transform_pib_nominal(conn, filepath: str):
    """
    Limpia y carga PIB per cápita nominal.
    Decisiones:
    - UPDATE si el año ya existe (del PIB real); INSERT si es nuevo.
    - Período puede llegar como string o como número serial de Excel.
    """
    log.info("→ [2/5] PIB nominal: leyendo %s", filepath)
    df = pd.read_excel(filepath, engine="openpyxl")
    df.columns = [str(c).strip() for c in df.columns]

    rename = {}
    for col in df.columns:
        cl = col.lower()
        if "período" in cl or "periodo" in cl or "año" in cl:
            rename[col] = "periodo"
        elif "nominal" in cl or ("pib" in cl and "percapita" in cl):
            rename[col] = "pib_percapita_nominal"
    df.rename(columns=rename, inplace=True)

    df = df[df["periodo"].notna()].copy()
    df["periodo"] = pd.to_datetime(df["periodo"], errors="coerce")
    df = df[df["periodo"].notna()].copy()
    df["anio"] = df["periodo"].dt.year
    df["pib_percapita_nominal"] = pd.to_numeric(df["pib_percapita_nominal"], errors="coerce")

    updated = inserted = 0
    for _, row in df.iterrows():
        anio = int(row["anio"])
        val  = row["pib_percapita_nominal"]
        cur  = conn.execute(
            "UPDATE fact_macro_anual SET pib_percapita_nominal=? WHERE id_tiempo IN (SELECT id_tiempo FROM dim_tiempo WHERE anio=?)",
            (val, anio)
        )
        if cur.rowcount > 0:
            updated += 1
        else:
            id_t = upsert_dim_tiempo(conn, f"{anio}-01-01")
            conn.execute("INSERT INTO fact_macro_anual (id_tiempo, pib_percapita_nominal) VALUES (?,?)", (id_t, val))
            inserted += 1
    conn.commit()
    log.info("   %d actualizados, %d insertados en fact_macro_anual.", updated, inserted)


# ─────────────────────────────────────────────────────────────
# FUNCIÓN 3 — VAB POR PROVINCIA
# ─────────────────────────────────────────────────────────────
def transform_vab(conn, filepath: str):
    """
    Limpia y carga VAB por provincia e industria.
    Decisiones:
    - Normalizar primero en dim_geografia (provincia + cantón).
    - Title Case en nombres geográficos para consistencia.
    - Nulos en VAB_miles_usd se conservan como NULL (no imputar).
    - Duplicados exactos eliminados con drop_duplicates().
    """
    log.info("→ [3/5] VAB: leyendo %s", filepath)
    df = pd.read_excel(filepath, engine="openpyxl")
    df.columns = [str(c).strip().upper() for c in df.columns]

    rename = {}
    for col in df.columns:
        cl = col.lower()
        if cl in ("año", "anio", "year"):          rename[col] = "anio"
        elif "cod" in cl and "prov" in cl:         rename[col] = "cod_provincia"
        elif "provincia" in cl and "cod" not in cl:rename[col] = "provincia"
        elif "cod" in cl and "canton" in cl:       rename[col] = "cod_canton"
        elif "canton" in cl and "cod" not in cl:   rename[col] = "canton"
        elif "ciiu" in cl:                         rename[col] = "ciiu"
        elif "vab" in cl:                          rename[col] = "vab_miles_usd"
    df.rename(columns=rename, inplace=True)

    df = df.drop_duplicates()
    df = df[df["anio"].notna() & df["provincia"].notna()].copy()
    df["anio"]          = df["anio"].astype(int)
    df["cod_provincia"] = pd.to_numeric(df["cod_provincia"], errors="coerce").fillna(0).astype(int)
    df["cod_canton"]    = pd.to_numeric(df.get("cod_canton", 0), errors="coerce").fillna(0).astype(int)
    df["vab_miles_usd"] = pd.to_numeric(df["vab_miles_usd"], errors="coerce")
    df["ciiu"]          = df["ciiu"].astype(str).str.strip()

    log.info("   %d filas limpias", len(df))

    for _, row in df.iterrows():
        id_geo = upsert_dim_geografia(conn, row["provincia"], row["cod_provincia"],
                                      row.get("canton", ""), row["cod_canton"])
        id_t   = upsert_dim_tiempo(conn, f"{int(row['anio'])}-01-01")
        conn.execute(
            "INSERT INTO fact_vab (id_geo, id_tiempo, anio, ciiu, vab_miles_usd) VALUES (?,?,?,?,?)",
            (id_geo, id_t, int(row["anio"]), row["ciiu"], row["vab_miles_usd"])
        )
    conn.commit()
    log.info("    %d registros en fact_vab.", len(df))


# ─────────────────────────────────────────────────────────────
# FUNCIÓN 4 — PETRÓLEO / RIESGO PAÍS
# ─────────────────────────────────────────────────────────────
def transform_petroleo(conn, filepath: str, filepath2: str = None):
    """
    Limpia y carga indicadores diarios: WTI y riesgo país.
    Decisiones:
    - Acepta 1 o 2 archivos (el BCE a veces los separa).
    - Fines de semana sin cotización → NULL (comportamiento normal del mercado).
    - Duplicados por fecha: keep='first'.
    """
    log.info("→ [4/5] Petróleo/Riesgo: leyendo %s", filepath)
    df = pd.read_excel(filepath, engine="openpyxl")
    df.columns = [str(c).strip() for c in df.columns]

    if filepath2 and Path(filepath2).exists():
        df2 = pd.read_excel(filepath2, engine="openpyxl")
        df2.columns = [str(c).strip() for c in df2.columns]
        df = pd.merge(df, df2, on=df.columns[0], how="outer")

    rename = {}
    for col in df.columns:
        cl = col.lower()
        if "período" in cl or "periodo" in cl or "fecha" in cl: rename[col] = "fecha"
        elif "wti" in cl or "petroleo" in cl or "petróleo" in cl: rename[col] = "precio_petroleo_wti"
        elif "riesgo" in cl or "embi" in cl:                    rename[col] = "riesgo_pais_pb"
    df.rename(columns=rename, inplace=True)

    df["fecha"] = pd.to_datetime(df["fecha"], errors="coerce")
    df = df[df["fecha"].notna()].copy()
    df["fecha_str"] = df["fecha"].dt.strftime("%Y-%m-%d")
    df = df.drop_duplicates(subset=["fecha_str"], keep="first")

    for col in ["precio_petroleo_wti", "riesgo_pais_pb"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    log.info("   %d filas limpias", len(df))

    for _, row in df.iterrows():
        id_t = upsert_dim_tiempo(conn, row["fecha_str"])
        conn.execute(
            "INSERT INTO fact_ind_diarios (id_tiempo, fecha, precio_petroleo_wti, riesgo_pais_pb) VALUES (?,?,?,?)",
            (id_t, row["fecha_str"], row.get("precio_petroleo_wti"), row.get("riesgo_pais_pb"))
        )
    conn.commit()
    log.info("    %d registros en fact_ind_diarios.", len(df))


# ─────────────────────────────────────────────────────────────
# FUNCIÓN 5 — IEE EXPECTATIVAS EMPRESARIALES
# ─────────────────────────────────────────────────────────────
def transform_iee(conn, filepath: str):
    """
    Limpia y carga IEE mensual desde 2010.
    Decisiones:
    - Fecha como string 'AAAA-MM-DD' → pd.to_datetime() con errors='coerce'.
    - Nulos en sectores se conservan como NULL.
    """
    log.info("→ [5/5] IEE: leyendo %s", filepath)
    df = pd.read_excel(filepath, engine="openpyxl")
    df.columns = [str(c).strip() for c in df.columns]

    rename = {}
    for col in df.columns:
        cl = col.lower()
        if "fecha" in cl or "período" in cl or "periodo" in cl: rename[col] = "fecha"
        elif "global" in cl or "iee" in cl:                     rename[col] = "iee_global"
        elif "comercio" in cl:                                   rename[col] = "comercio"
        elif "construc" in cl:                                   rename[col] = "construccion"
        elif "manufactura" in cl:                                rename[col] = "manufactura"
    df.rename(columns=rename, inplace=True)

    df["fecha"] = pd.to_datetime(df["fecha"], errors="coerce")
    df = df[df["fecha"].notna()].copy()
    df["fecha_str"] = df["fecha"].dt.strftime("%Y-%m-%d")

    for col in ["iee_global", "comercio", "construccion", "manufactura"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    log.info("   %d filas limpias", len(df))

    for _, row in df.iterrows():
        id_t = upsert_dim_tiempo(conn, row["fecha_str"])
        conn.execute(
            "INSERT INTO fact_iee (id_tiempo, fecha, iee_global, comercio, construccion, manufactura) VALUES (?,?,?,?,?,?)",
            (id_t, row["fecha_str"], row.get("iee_global"), row.get("comercio"),
             row.get("construccion"), row.get("manufactura"))
        )
    conn.commit()
    log.info("    %d registros en fact_iee.", len(df))


# ─────────────────────────────────────────────────────────────
# VERIFICACIÓN RÁPIDA
# ─────────────────────────────────────────────────────────────
def verificar_carga():
    conn = get_connection()
    tablas = ["dim_tiempo", "dim_geografia",
              "fact_macro_anual", "fact_ind_diarios", "fact_vab", "fact_iee"]
    print("\n" + "="*48)
    print("  VERIFICACIÓN — Capa Silver BCE")
    print("="*48)
    for t in tablas:
        n = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        print(f"  {t:<30} {n:>8} registros")
    print("="*48 + "\n")
    conn.close()


# ─────────────────────────────────────────────────────────────
# ORQUESTADOR PRINCIPAL
# ─────────────────────────────────────────────────────────────
def run_bce_pipeline():
    archivos = {
        "pib_real"   : BRONZE_DIR / "bce_pib_real.xlsx",
        "pib_nominal": BRONZE_DIR / "bce_pib_pc.xlsx",
        "vab"        : BRONZE_DIR / "bce_vab_prov.xlsx",
        "petroleo"   : BRONZE_DIR / "bce_petroleo_iee.xlsx",
        "iee"        : BRONZE_DIR / "bce_iee.xlsx",   # si viene separado
    }

    conn = get_connection()
    try:
        create_tables(conn)

        for nombre, ruta in [
            ("pib_real",    archivos["pib_real"]),
            ("pib_nominal", archivos["pib_nominal"]),
            ("vab",         archivos["vab"]),
            ("petroleo",    archivos["petroleo"]),
        ]:
            if ruta.exists():
                {"pib_real":    transform_pib_real,
                 "pib_nominal": transform_pib_nominal,
                 "vab":         transform_vab,
                 "petroleo":    transform_petroleo}[nombre](conn, str(ruta))
            else:
                log.warning("  Archivo no encontrado: %s", ruta)

        # IEE: archivo separado o dentro del de petróleo
        if archivos["iee"].exists():
            transform_iee(conn, str(archivos["iee"]))
        elif archivos["petroleo"].exists():
            log.info("   IEE: leyendo desde archivo de petróleo.")
            transform_iee(conn, str(archivos["petroleo"]))
        else:
            log.warning("  Archivo IEE no encontrado.")

        log.info(" Pipeline BCE completado exitosamente.")

    except Exception as e:
        log.error(" Error: %s", e)
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    run_bce_pipeline()
    verificar_carga()
