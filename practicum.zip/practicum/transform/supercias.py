"""
transform/supercias.py
======================
ETL Capa Bronze → Silver  |  Fuentes: Supercias
Semana 3 · Prácticum DGTITD-UTPL

Fuentes que procesará:
  1. Ranking de empresas  → fact_empresas
  2. Directorio           → fact_empresas (conteo activas por provincia)
"""

# TODO Semana 3


def run_supercias_pipeline():
    raise NotImplementedError("Implementar en Semana 3")
